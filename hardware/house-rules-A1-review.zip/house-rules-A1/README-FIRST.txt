House Rules A1 — engineering review bundle, 29 October 2026.

Open hardware/design-summary.html first. Native KiCad projects and manufacturer
review files, compiled prototype firmware, pin model and printable fit tools are
included. The supplied main.py and sequence.json support the artwork exporter.

This is not an order approval. Seven-module fit, low-current pin/polarity proof,
manufacturer placement/process review and the first-unit bench tests remain.
No stock has been reserved and no board has been purchased.

Use the final native PCB files. Experimental routing sessions/backups and older
progress reports are omitted. The placement generator deliberately discards
routing; do not run it casually over the final boards.
